﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades;

namespace VistaForm
{
    public partial class frmDT : Form
    {
        DirectorTecnico directorTecnico;
        public frmDT()
        {
            InitializeComponent();
        }

        private void btnCrear_Click(object sender, EventArgs e)
        {
            directorTecnico = new DirectorTecnico(txtNombre.Text, txtApellido.Text, (int)nudEdad.Value, (int)nudDni.Value, (int)nudExperiencia.Value);

            MessageBox.Show("Se ha creado el DT");

            Limpiar();
        }

        private void btnValidar_Click(object sender, EventArgs e)
        {
            if(directorTecnico == null)
            {
                MessageBox.Show("Aun no se ha creado el DT del formulario");
            }
            else if(directorTecnico.ValidarAptitud())
            {
                MessageBox.Show("El DT es apto");
            }
            else
            {
                MessageBox.Show("El DT no es apto");
            }
        }

        public void Limpiar()
        {
            foreach(var item in Controls)
            {
                if(item is TextBox)
                {
                    ((TextBox)item).Text = "";
                }
                if(item is NumericUpDown)
                {
                    ((NumericUpDown)item).Value = 0;
                }
            }
        }
    }
}
