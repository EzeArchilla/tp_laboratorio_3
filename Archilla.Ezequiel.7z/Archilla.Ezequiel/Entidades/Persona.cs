﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public abstract class Persona
    {
        private String apellido;
        private int dni;
        private int edad;
        private String nombre;

        public String Apellido { get { return this.apellido; } }
        public int Dni { get { return this.dni; } }
        public int Edad { get { return this.edad; } }
        public String Nombre { get { return this.nombre; } }

        public Persona(String nombre, String apellido, int edad, int dni)
        {
            this.nombre = nombre;
            this.apellido = apellido;
            this.dni = dni;
            this.edad = edad;
        }

        public virtual String Mostrar()
        {
            StringBuilder str = new StringBuilder();

            str.AppendLine("-------------------------------------------")
                .AppendLine("Nombre y Apellido: " + Nombre + " " + Apellido)
                .AppendLine("Edad: " + Edad)
                .AppendLine("Dni: " + Dni);

            return str.ToString();
        }

        public abstract bool ValidarAptitud();
    }
}
