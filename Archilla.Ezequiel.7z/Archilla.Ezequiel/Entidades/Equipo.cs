﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Equipo
    {
        const int cantidadMaximaJugadores = 6;
        private DirectorTecnico directorTecnico;
        private List<Jugador> jugadores;
        private String nombre;

        private Equipo()
        {
            jugadores = new List<Jugador>();
        }

        public Equipo(String nombre) : this()
        {
            this.nombre = nombre;
        }

        public DirectorTecnico DirectorTecnico
        {
            set
            {
                if(value.ValidarAptitud())
                {
                    this.directorTecnico = value;
                }
            }
        }

        public static explicit operator String(Equipo e)
        {
            StringBuilder str = new StringBuilder();

            if(!(e.directorTecnico is null))
            {
                str.AppendLine("Director Tecnico: ")
                    .AppendLine(e.directorTecnico.Mostrar());
            }else
            {
                str.AppendLine("Sin DT asignado");
            }

            foreach(Jugador player in e.jugadores)
            {
                str.AppendLine(player.Mostrar());
            }

            return str.ToString();
        }

        public static bool operator ==(Equipo e, Jugador j)
        {
            foreach(Jugador player in e.jugadores)
            {
                if(j == player)
                {
                    return true;
                }
            }
            return false;
        }

        public static bool operator !=(Equipo e, Jugador j)
        {
            return (!(e == j));
        }

        public static Equipo operator +(Equipo e, Jugador j)
        {
            if(e != j && e.jugadores.Count < 6 && j.ValidarAptitud())
            {
                e.jugadores.Add(j);
            }

            return e;
        }

        public static bool ValidarEquipo(Equipo e)
        {
            int cantidadJugadores = 0;

            int cantArquero = 0;
            bool hayDelantero = false;
            bool hayDefensor = false;
            bool hayCentral = false;
            
            
            if(e.directorTecnico != null)
            {
                foreach(Jugador player in e.jugadores)
                {
                    switch(player.Posicion)
                    {
                        case Posicion.Delantero:
                            hayDelantero = true;
                            break;
                        case Posicion.Defensor:
                            hayDefensor = true;
                            break;
                        case Posicion.Arquero:
                            cantArquero++ ;
                            break;
                        case Posicion.Central:
                            hayCentral = true;
                            break;
                    }
                    cantidadJugadores++;
                }

                return (hayDelantero && hayDefensor && hayCentral && cantArquero == 1 && cantidadJugadores == cantidadMaximaJugadores);
            }
            return false;
        }
    }
}
