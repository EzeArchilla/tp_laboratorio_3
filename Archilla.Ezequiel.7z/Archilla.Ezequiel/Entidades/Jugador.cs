﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Jugador : Persona
    {
        private float altura;
        private float peso;
        private Posicion posicion;

        public float Altura { get { return this.altura; } }
        public float Peso { get { return this.peso; } }
        public Posicion Posicion { get { return this.posicion; } }

        public Jugador(String nombre, String apellido, int edad, int dni, float peso, float altura, Posicion posicion):base(nombre,apellido,edad,dni)
        {
            this.altura = altura;
            this.peso = peso;
            this.posicion = posicion;
        }

        public override string Mostrar()
        {
            StringBuilder str = new StringBuilder();

            str.AppendLine(base.Mostrar())
                .AppendLine("Peso: " + Peso + "  Altura: " + Altura)
                .AppendLine("Posicion: " + Posicion);

            return str.ToString();
        }

        public bool ValidarEstadoFisico()
        {
            float calculoMasaCorporal = (float)Peso / (float)(Math.Pow(Altura, 2));
            if(calculoMasaCorporal >= 18.5 && calculoMasaCorporal <= 25)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public override bool ValidarAptitud()
        {
            return (base.Edad <= 40 && ValidarEstadoFisico());
        }
    }
}
