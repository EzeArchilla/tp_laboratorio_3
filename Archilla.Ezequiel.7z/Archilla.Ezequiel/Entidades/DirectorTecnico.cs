﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class DirectorTecnico : Persona
    {
        private int añosExperiencia;

        public int AñosExperiencia
        {
            get { return this.añosExperiencia; }
            set { this.añosExperiencia = value; }
        }

        public DirectorTecnico(String nombre, String apellido, int edad, int dni, int añosExperiencia):base(nombre,apellido,edad,dni)
        {
            AñosExperiencia = añosExperiencia;
        }

        public override string Mostrar()
        {
            StringBuilder str = new StringBuilder();

            str.AppendLine(base.Mostrar())
                .AppendLine("Años de Experiencia: " + AñosExperiencia);

            return str.ToString();
        }

        public override bool ValidarAptitud()
        {
            return (base.Edad <= 65 && AñosExperiencia >= 2);
        }
    }
}
